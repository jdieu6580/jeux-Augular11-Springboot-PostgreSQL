function calculateTip() {
    const billAmount = parseFloat(document.getElementById('billAmount').value);
    let tipPercentage = 0;

    if (billAmount > 300) {
        tipPercentage = 5;
    } else if (billAmount > 100) {
        tipPercentage = 10;
    } else if (billAmount === 100) {
        tipPercentage = 10;
    }

    const tipAmount = (billAmount * tipPercentage) / 100;
    document.getElementById('tipAmount').textContent = `Montant du pourboire : $${tipAmount.toFixed(2)}`;
}